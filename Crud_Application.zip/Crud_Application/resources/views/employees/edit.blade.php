<!-- resources/views/employees/edit.blade.php -->

@extends('employees.layout')
@section('content')

                <div class="card" style="margin:20px;">
                    <div class="card-header">Edit Employee</div>
                    <div class="card-body">
                         
                        <form action="{{ url('employee/' .$employees->id) }}" method="post">
                          {!! csrf_field() !!}
                          @method("PATCH")
                          <div class="form-group">
                            <label for="employee_name">Name</label>
                            <input type="text" name="employee_name" class="form-control" value="{{ $employees->employee_name }}">
                        </div>
                        <div class="form-group">
                            <label for="employee_email">Email</label>
                            <input type="email" name="employee_email" class="form-control" value="{{ $employees->employee_email }}">
                        </div>
                        <div class="form-group">
                            <label for="phone_no">Phone</label>
                            <input type="text" name="phone_no" class="form-control" value="{{ $employees->phone_no }}">
                        </div>
                        <div class="form-group">
                            <label for="cnic_no">CNIC</label>
                            <input type="text" name="cnic_no" class="form-control" value="{{ $employees->cnic_no }}">
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                    </form>
                      
                    </div>
                  </div>
                </div>
                  @stop




                  