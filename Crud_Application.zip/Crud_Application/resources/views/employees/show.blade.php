<!-- resources/views/employees/show.blade.php -->

@extends('employees.layout')
@section('content')
  
<div class="card" style="margin:20px;">
  <div class="card-header">Employee Detail</div>
  <div class="card-body">
        <div class="card-body">
        <h5 class="card-title">Name : {{ $employees->employee_name }}</h5>
        <p class="card-text">Email : {{ $employees->employee_email }}</p>
        <p class="card-text">Phone : {{ $employees->phone_no }}</p>
        <p class="card-text">CNIC : {{ $employees->cnic_no }}</p>
    </div>
</hr>
</div>
</div>