<!-- resources/views/employees/show.blade.php -->


<?php $__env->startSection('content'); ?>
  
<div class="card" style="margin:20px;">
  <div class="card-header">Employee Detail</div>
  <div class="card-body">
        <div class="card-body">
        <h5 class="card-title">Name : <?php echo e($employees->employee_name); ?></h5>
        <p class="card-text">Email : <?php echo e($employees->employee_email); ?></p>
        <p class="card-text">Phone : <?php echo e($employees->phone_no); ?></p>
        <p class="card-text">CNIC : <?php echo e($employees->cnic_no); ?></p>
    </div>
</hr>
</div>
</div>
<?php echo $__env->make('employees.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crud_Application\resources\views/employees/show.blade.php ENDPATH**/ ?>