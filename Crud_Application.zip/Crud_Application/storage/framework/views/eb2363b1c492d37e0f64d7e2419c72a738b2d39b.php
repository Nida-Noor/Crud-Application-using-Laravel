<!-- resources/views/employees/edit.blade.php -->


<?php $__env->startSection('content'); ?>

                <div class="card" style="margin:20px;">
                    <div class="card-header">Edit Employee</div>
                    <div class="card-body">
                         
                        <form action="<?php echo e(url('employee/' .$employees->id)); ?>" method="post">
                          <?php echo csrf_field(); ?>

                          <?php echo method_field("PATCH"); ?>
                          <div class="form-group">
                            <label for="employee_name">Name</label>
                            <input type="text" name="employee_name" class="form-control" value="<?php echo e($employees->employee_name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="employee_email">Email</label>
                            <input type="email" name="employee_email" class="form-control" value="<?php echo e($employees->employee_email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="phone_no">Phone</label>
                            <input type="text" name="phone_no" class="form-control" value="<?php echo e($employees->phone_no); ?>">
                        </div>
                        <div class="form-group">
                            <label for="cnic_no">CNIC</label>
                            <input type="text" name="cnic_no" class="form-control" value="<?php echo e($employees->cnic_no); ?>">
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                    </form>
                      
                    </div>
                  </div>
                </div>
                  <?php $__env->stopSection(); ?>




                  
<?php echo $__env->make('employees.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crud_Application\resources\views/employees/edit.blade.php ENDPATH**/ ?>