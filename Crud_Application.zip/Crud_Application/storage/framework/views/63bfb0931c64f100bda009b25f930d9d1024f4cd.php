<!-- resources/views/employees/create.blade.php -->

<?php $__env->startSection('content'); ?>
  
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Add Employee</h2>
                      <form action="<?php echo e(url('employee')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="employee_name">Name</label>
                        <input type="text" name="employee_name" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="employee_email">Email</label>
                        <input type="email" name="employee_email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="phone_no">Phone</label>
                        <input type="text" name="phone_no" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="cnic_no">CNIC</label>
                        <input type="text" name="cnic_no" class="form-control">
                    </div>
                    <input type="submit" value="Save" class="btn btn-success"></br>
                </form>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('employees.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crud_Application\resources\views/employees/create.blade.php ENDPATH**/ ?>